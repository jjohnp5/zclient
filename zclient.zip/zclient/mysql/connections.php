<?php
$connect = mysqli_connect("localhost", "johnlagm_john", "USnavy1989", "johnlagm_users");
if(mysqli_connect_error()){
    die("Database connection failed.");
}
 ?>
